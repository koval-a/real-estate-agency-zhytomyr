<?php

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div class="maxwidth">
<h1><?php  echo TrustindexPlugin::___("Support"); ?></h1>
<p><?php  echo TrustindexPlugin::___('If you have any questions or problem, please send an email to support@trustindex.io and our colleagues will answer you in 48 hours!'); ?></p>
</div>