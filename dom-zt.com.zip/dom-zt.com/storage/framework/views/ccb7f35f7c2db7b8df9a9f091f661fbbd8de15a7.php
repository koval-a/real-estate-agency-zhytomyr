   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">About</div>
                <div class="card-body">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error quam soluta, culpa corporis incidunt reprehenderit eius quis magnam iusto sapiente velit fugiat deleniti consequuntur et atque dolorem vero eligendi quas?
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/real-estate-agency-zhytomyr/dom-zt.com/resources/views/pages/about.blade.php ENDPATH**/ ?>