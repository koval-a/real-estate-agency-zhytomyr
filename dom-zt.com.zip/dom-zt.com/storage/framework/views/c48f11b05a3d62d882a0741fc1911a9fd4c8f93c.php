<?php $__env->startSection('content'); ?>

        <div class="reiltor mt-2 mb-5">
            <h1>Ріелтори</h1>
            <hr>
            <div class="container-fluid">
                <p class="mt-5">Список зареєстрованих реєлторів</p>
            </div>
            <?php echo e($dataRieltors ?? 'Пусто'); ?>


                <?php $__currentLoopData = $dataRieltors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rieltor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span>
                    <?php echo e($rieltor->name); ?>

                </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/real-estate-agency-zhytomyr/dom-zt.com/resources/views/admin/rieltor/index.blade.php ENDPATH**/ ?>