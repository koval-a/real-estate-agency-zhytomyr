@extends('layouts.rieltor')

@section('content')

    <div class="reiltor">
        <h1>Ріелтори Аккаунт</h1>
    </div>

@endsection

