@extends('layouts.app')
   
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">About</div>
                <div class="card-body">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error quam soluta, culpa corporis incidunt reprehenderit eius quis magnam iusto sapiente velit fugiat deleniti consequuntur et atque dolorem vero eligendi quas?
                </div>
            </div>
        </div>
    </div>
</div>
@endsection